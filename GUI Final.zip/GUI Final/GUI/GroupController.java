
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.ListView;
import com.storeCredentials;
import javafx.fxml.Initializable;
import java.util.ArrayList;

public class GroupController implements Initializable{
	private Connection con;
	private Statement st;
	private ResultSet rs;
	@FXML
	public ListView taskList;
	@FXML
	public void showHomePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Home.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	
	public void viewFilePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/IndividualGroupFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void createFilePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/createShareLatexFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void viewArchivePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/GroupsArchive.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void downloadFile(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/DownloadFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	
	}
	
	public void emailFile(ActionEvent event) throws IOException {
		
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/email.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
		
	}
	
	public void deleteFile(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/DeleteFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
		
	}
	
	public void uploadFile(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/UploadFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
		
	}
	
	public void gitOnOff(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/GITpage.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
		
		
	}
	@FXML
	public void createTask(ActionEvent event) throws IOException {
		
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/tasksPage.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
		
	} 

	public void showForgotPass(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/forgotPassPage.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void showLogin(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/loginScreenBuilder.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	@Override
	public void initialize(URL url, ResourceBundle rb){
		//initializing connection between database
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://csmysql.cs.cf.ac.uk/c1522412","c1522412","UQPOMhh3g");
			if(con != null) {
				st = con.createStatement();
				}
			else{
				System.out.println("did not connect");
			}
			
		}catch(Exception ex){
			System.out.println("Error: "+ex);
		}
		//getting the name of user who has logged in
		String queryName=storeCredentials.username;
		ArrayList<String> task_list = new ArrayList<String>();
		String taskquery = "SELECT taskname, date, time FROM calendar WHERE assignname = '"+queryName+"'";
		try {
			rs = st.executeQuery(taskquery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(rs.next()){
				task_list.add(rs.getString("taskname")+" "+rs.getString("date")+" "+rs.getString("time"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end if
		System.out.println(task_list);
		taskList.setItems(FXCollections.observableArrayList(task_list));

}//end method
	
	public void doneTask(ActionEvent event) throws IOException {
		String chosenTask = (String) taskList.getSelectionModel().getSelectedItem();
		String[] split_task = chosenTask.trim().split("\\s+");
		String taskquery = "DELETE FROM calendar WHERE taskname = '"+split_task[0]+"' AND date ='"+split_task[1]+"' AND time = '"+split_task[2]+"'";
		try {
			st.executeUpdate(taskquery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}//end class

