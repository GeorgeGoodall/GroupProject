import java.io.IOException;
import com.jcraft.jsch.*;
import java.util.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class downloadFileController {
	
	@FXML
	private Text txt_error;
	@FXML
	private PasswordField passFieldDownload;
	
	@FXML
	private TextField usernameBox;
	
	@FXML
	private TextField filenameBox;
	
	@FXML
	private TextField serverBox;
	
	@FXML
	private TextField fileOrginalName;
	
	@FXML
	private TextField directoryBox;
	
	@FXML
	public void downloadFile(ActionEvent event) throws IOException {
		//testing if login details are correct go here
		int sFTPPORT = 22;
		String sFTPUSER = "ubuntu";
		String directoryToDownloadFrom = filenameBox.getText();
		String sFTPHOST = "10.72.97.107";
		String sFTPPASS = "../keys/id_rsa";
		String sFTPWORKINGDIR = "Documents/Archive";
		String fileName = fileOrginalName.getText();
		Session session = null;
		Channel channel = null;
        ChannelSftp channelSftp = null;
        try {
            JSch jsch = new JSch();
            jsch.addIdentity(sFTPPASS);
            session = jsch.getSession(sFTPUSER, sFTPHOST, sFTPPORT);
            session.setPassword(sFTPPASS);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            channelSftp = (ChannelSftp) channel;
            channelSftp.cd(sFTPWORKINGDIR);
            channelSftp.get(fileName, directoryToDownloadFrom);

        } catch (Exception ex) {
        	((Node) (event.getSource())).getScene().getWindow().hide();
    		Stage stage = new Stage();
    		Parent root = FXMLLoader.load(getClass().getResource("/DownloadFail.fxml"));
    		Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();
            return;
        }
        finally{

            channelSftp.exit();
            channel.disconnect();
            session.disconnect();
        }
		//String sFTPPASS = passFieldDownload.getText();
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/DownloadOK.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	public void showRegister(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Register.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	@FXML
    void initialize() {
        assert passFieldDownload != null : "fx:id=\"passFieldDownload\" was not injected: check your FXML file 'passport.fxml'.";
        assert usernameBox != null : "fx:id=\"usernameBox\" was not injected: check your FXML file 'passport.fxml'.";
        assert filenameBox != null : "fx:id=\"filenameBox\" was not injected: check your FXML file 'passport.fxml'.";

    }
	
	
}
