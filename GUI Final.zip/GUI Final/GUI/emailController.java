//import java.awt.TextField;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.fxml.FXML;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

public class emailController {
	@FXML
    private TextField uniEmail;
	@FXML
    private PasswordField uniPassword;
	@FXML
    private TextField toEmail;
	@FXML
    private TextField subject;
	@FXML
    private TextArea messageText;
	@FXML
	private Label mSendLbl;
	@FXML
	public void showHomePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Home.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
        
	}
	
	@FXML
	public void viewFilePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/GroupsFiles.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	@FXML
	public void createFilePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/createShareLatexFile.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	@FXML
	public void viewArchivePage(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/GroupsArchive.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void gitOnOff(ActionEvent event) throws IOException {
		
		
	}
	
	public void clearFields(){
		uniEmail.setText("");
        uniPassword.clear();
        toEmail.setText("");
        subject.clear();
        messageText.clear();
	}
	
	@FXML
	public void sendEmail(ActionEvent event) throws IOException{
//		String text = messageText.getText();
		
		Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "outlook.office365.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(uniEmail.getText(),uniPassword.getText());
            }
          });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(uniEmail.getText()));
            message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(toEmail.getText()));
            message.setSubject(subject.getText());
            message.setText(messageText.getText());

            Transport.send(message);

            System.out.println("Done");
            clearFields();
            mSendLbl.setText("Message Sent");
           
            

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
	}
	
	public void showLogin(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/loginScreenBuilder.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	public void showForgotPass(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/forgotPassPage.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
}

		
		

