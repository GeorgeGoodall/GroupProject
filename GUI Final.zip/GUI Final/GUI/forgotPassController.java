//import static ForgotPass.DB_URL;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import com.storeCredentials;
import com.encrDecr;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;

public class forgotPassController {
    
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://csmysql.cs.cf.ac.uk/c1522412" ;

    //  Database credentials
    static final String USER = "c1522412";
    static final String PASS = "UQPOMhh3g";

    @FXML
    private TextField oldPass;
    @FXML
    private PasswordField password;
    @FXML
    private PasswordField passwordRepeat;
    @FXML 
    private TextArea error;
	
	public void showHome(ActionEvent event) throws IOException {
		ArrayList<String> errors = new ArrayList<String>();
                error.clear();
                if(password.getText().length()<8){
                errors.add("Password too short");
            }
                if(password.getText().length()>30){
                errors.add("Password too long");
            }
                Pattern hasUppercase = Pattern.compile("([A-Z])");
                Pattern hasLowercase = Pattern.compile("([a-z])");
                Pattern hasNumber = Pattern.compile("\\d");
                
                if (!hasUppercase.matcher(password.getText()).find()) {
                //logger.info(password + " <-- needs uppercase");
                errors.add("Password needs at least 1 upper case letter");
            }
                  if (!hasLowercase.matcher(password.getText()).find()) {
                //logger.info(password + " <-- needs uppercase");
                errors.add("Password needs at least 1 lower case letter");
            }
                 if (!hasNumber.matcher(password.getText()).find()) {
                //logger.info(password + " <-- needs uppercase");
                errors.add("Password needs at least 1 digit");
            }

                if (!password.getText().equals(passwordRepeat.getText())){
                    //System.out.println("passwords don't match");
                    errors.add("Passwords don't match");
                }
                
                encrDecr encrypt = new encrDecr();
                String encrOldPass = encrypt.Encryption(oldPass.getText());
                
//                System.out.println(encrOldPass);
//                System.out.println(storeCredentials.oldPassword);
                if(!encrOldPass.equals(storeCredentials.oldPassword)){
                    errors.add("Old Password incorrect");
                  //  error.setText("Old password incorrect");
                }
                 if(errors.size()==0){
                    System.out.println("Reached");
                    Connection conn = null;
                    Statement stmt = null;
                    try{

                    //STEP 3: Open a connection
                    System.out.println("Connecting to database...");
                    conn = DriverManager.getConnection(DB_URL,USER,PASS);

                    //STEP 4: Execute a query
                    System.out.println("Creating statement...");
                    stmt = conn.createStatement();
                    String sqlChangePass = "UPDATE Users SET password = ?  WHERE UserName = ?" ;
                    PreparedStatement preparedStmt = conn.prepareStatement(sqlChangePass);
                    
                    //encrypt the new pass before storing
                    encrDecr encryptNewPass = new encrDecr();
                    String newPass = encryptNewPass.Encryption(password.getText());
                 
                    preparedStmt.setString   (1, newPass);
                    preparedStmt.setString   (2, storeCredentials.username);
                    preparedStmt.executeUpdate();
                    System.out.println("Pass changed");
                    
                    //return to the home screen
                    ((Node) (event.getSource())).getScene().getWindow().hide();
                    Stage stage = new Stage();
                    Parent root = FXMLLoader.load(getClass().getResource("/forgotPassPage.fxml"));
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.setTitle("Login");
                    stage.show();
                    
                    }catch(SQLException se){
                        //Handle errors for JDBC
                        se.printStackTrace();
                     }catch(Exception e){
                        //Handle errors for Class.forName
                        e.printStackTrace();
                     }finally{
                        //finally block used to close resources
                        try{
                           if(stmt!=null)
                              stmt.close();
                        }catch(SQLException se2){
                        }// nothing we can do
                        try{
                           if(conn!=null)
                              conn.close();
                        }catch(SQLException se){
                           se.printStackTrace();
                        }
                     }
                   
                    
                }else{
                     for (int i=0; i<errors.size();i++){
                    error.appendText( errors.get(i).toString());
                    error.appendText("\n");
                }
                 
                 }
        }
        public void goBack(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Home.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
}

		
		

