

import javafx.scene.control.TextField;

import javafx.scene.control.TextArea;

import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JPanel;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class GITpageController extends JPanel{
	

	
	@FXML private ListView<String> untrackedFiles;
	@FXML private ListView<String> modifiedFiles;
	@FXML private ListView<String> addedFiles;
	@FXML private ListView<String> upToDateFiles;
	@FXML private ListView<String> Branches;
	@FXML private TextField repoURL;
	@FXML private TextField commitMessage;
	@FXML private TextField branchName;
	@FXML private TextArea output;
	
	
	GitJava gj;
	String directory;
	boolean firsttime = true;
	
	public String[] obsToArr(ObservableList<String> list){
		String[] toReturn = new String[list.size()];
		for(int i = 0; i<list.size();i++){
			toReturn[i] = list.get(i);
		}
		return toReturn;
	}

	public void add(ActionEvent event) throws IOException{
		String[] untracked = obsToArr(untrackedFiles.getSelectionModel().getSelectedItems());		
		String[] modified = obsToArr(modifiedFiles.getSelectionModel().getSelectedItems());
		String[] toAdd = new String[untracked.length + modified.length];
		
		System.arraycopy(untracked, 0, toAdd, 0, untracked.length);
		System.arraycopy(modified, 0, toAdd, untracked.length, modified.length);
		String[] out = gj.add(directory, toAdd);
		String out2 = "";
		for (int i = 0; i<out.length; i++){
			out2 = out2 + "\n" + out[i];
		}
		output.setText(out2);
		updateLists();

	}
	
	public void commit(ActionEvent event) throws IOException{
		String message = commitMessage.getText();
		String[] args = new String[]{"-m",message};
		gj.commit(directory, args);
		updateLists();
	}

	public void remove(ActionEvent event) throws IOException{
		String[] toRemove = obsToArr(upToDateFiles.getSelectionModel().getSelectedItems());
		String[] out = gj.remove(directory, toRemove);
		String out2 = "";
		for (int i = 0; i<out.length; i++){
			out2 = out2 + "\n" + out[i];
		}
		output.setText(out2);
		updateLists();
	}
	
	public void updateWindow(ActionEvent event) throws IOException{
		updateLists();
	}

	public void push(ActionEvent event) throws IOException{
		String url = repoURL.getText();
		gj.push(directory, url, getCurrentBranch());

		
		String location = "home/c1511942/yupp/";
		String[] out = gj.run(directory, location);
		String out2 = "";
		for (int i = 0; i<out.length; i++){
			out2 = out2 + "\n" + out[i];
		}
		output.setText(out2);

	}
	
	private String getCurrentBranch(){
		System.out.println("getting branch");
		ObservableList<String> branches = Branches.getItems();
		for (int i = 0; i<branches.size();i++){
			if (branches.get(i).charAt(0) == '*'){
				return branches.get(i).substring(2);
			}
		}
		return null;
	}

	public void pull(ActionEvent event) throws IOException{
		String url = repoURL.getText();
		String[] out = gj.pull(directory, url, getCurrentBranch());
		String out2 = "";
		for (int i = 0; i<out.length; i++){
			out2 = out2 + "\n" + out[i];
		}
		output.setText(out2);
		updateLists();
	}
	
	public void clone(ActionEvent event) throws IOException{
		String url = repoURL.getText();
		String[] args = new String[]{url};
		String[] out = gj.gitclone(directory, args);
		String out2 = "";
		for (int i = 0; i<out.length; i++){
			out2 = out2 + "\n" + out[i];
		}
		output.setText(out2);
		File folder = new File(directory);
		File[] files = folder.listFiles();
		directory = directory + "/" + files[0].getName();
		updateLists();
	}

	public void newBranch(ActionEvent event) throws IOException{
		String branchn = branchName.getText();
		String[] args = new String[]{branchn};
		gj.branch(directory, args);
		updateLists();
	}

	public void switchBranch(ActionEvent event) throws IOException{
		if(modifiedFiles.getItems().size()>0){
			output.setText("commit your changes before switching branch");
		}
		else{
			String branch = Branches.getSelectionModel().getSelectedItem();
			branch = branch.substring(2);
			String[] args = new String[]{branch};
			String[] out = gj.checkout(directory, args);
			String out2 = "";
			for (int i = 0; i<out.length; i++){
				out2 = out2 + "\n" + out[i];
			}
			output.setText(out2);
			updateLists();
		}
		
	}

	public void mergeBranch(ActionEvent event) throws IOException{
	
	}
	
	public void setDirectory(ActionEvent event) throws IOException{
		JFileChooser chooser = new JFileChooser(); 
	    chooser.setCurrentDirectory(new java.io.File("."));
	    chooser.setDialogTitle("select your git repo");
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    //
	    // disable the "All files" option.
	    //
	    chooser.setAcceptAllFileFilterUsed(false);
	    //    
	    if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) { 
	      System.out.println("getCurrentDirectory(): " +  chooser.getCurrentDirectory());
	      System.out.println("getSelectedFile() : " +  chooser.getSelectedFile());
	      directory = chooser.getSelectedFile().getPath();
	      gj = new GitJava();
	      updateLists();
	      }
	    else {
	      System.out.println("No Selection ");
	      }
	 }
	
	public void updateLists(){
		// make listViews multiselect
		if(firsttime){
			untrackedFiles.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
			modifiedFiles.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
			addedFiles.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
			upToDateFiles.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
			firsttime = false;
		}
		
		
		
		ObservableList<String> modified = FXCollections.observableArrayList();
		
		String[] status = gj.status(directory, new String[0]);
		String[] theModifiedFiles = gj.getModified(status);
		String[] theUntrackedFiles = gj.getUntracked(status);
		String[] theStagedFiles = gj.getStaged(status);
		String[] nonUpToDateFiles = new String[theModifiedFiles.length + theUntrackedFiles.length + theStagedFiles.length];
		System.arraycopy(theModifiedFiles, 0, nonUpToDateFiles, 0, theModifiedFiles.length);
		System.arraycopy(theUntrackedFiles, 0, nonUpToDateFiles, theModifiedFiles.length, theUntrackedFiles.length);
		System.arraycopy(theStagedFiles, 0, nonUpToDateFiles, theModifiedFiles.length + theUntrackedFiles.length, theStagedFiles.length);
		String[] theUpToDateFiles = gj.getUpToDate(directory,nonUpToDateFiles);
		
		
		String[] theBranches = gj.branch(directory, new String[]{"-a"});
		
		ObservableList<String> modifiedlist = FXCollections.observableArrayList(theModifiedFiles);
		modifiedFiles.setItems(modifiedlist);
		ObservableList<String> untrackedlist = FXCollections.observableArrayList(theUntrackedFiles);
		untrackedFiles.setItems(untrackedlist);
		ObservableList<String> addedlist = FXCollections.observableArrayList(theStagedFiles);
		addedFiles.setItems(addedlist);
		ObservableList<String> upToDateList = FXCollections.observableArrayList(theUpToDateFiles);
		upToDateFiles.setItems(upToDateList);
		ObservableList<String> branchList = FXCollections.observableArrayList(theBranches);
		Branches.setItems(branchList);
	}
}
		

