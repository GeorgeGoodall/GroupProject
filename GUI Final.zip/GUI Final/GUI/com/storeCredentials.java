/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author Ivonna
 */
public class storeCredentials {
    
    public static String oldPassword;
    public static String username;
//    
    public void storePass(String Pass) {
        this.oldPassword = Pass;        
    }    
    public void storeUsername(String user) {
        this.username = user;
        
    }
    public String getOldPass() {
        return oldPassword;
  }
    
    
    
}
