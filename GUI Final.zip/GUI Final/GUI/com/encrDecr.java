/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
import java.io.IOException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 *
 * @author Ivonna
 */
public class encrDecr {
   
    private String encrPass;
    
    public String Encryption(String Pass) {
      byte[] input;
      byte[] keyBytes = "12345678".getBytes();
      byte[] ivBytes = "fnYbw123".getBytes();    
      SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
      IvParameterSpec icSpec = new IvParameterSpec(ivBytes);
      Cipher cipher;
      byte[] cipherText;
      int ctLength;

      try{
          Security.addProvider(new BouncyCastleProvider());
          input = Pass.getBytes();
          IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
          cipher = Cipher.getInstance("DES/CTR/NoPadding", "BC");
          cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
          cipherText = new byte[cipher.getOutputSize(input.length)];
          ctLength = cipher.update(input, 0, input.length, cipherText, 0);
          ctLength += cipher.doFinal(cipherText, ctLength);
          System.out.println("cipher: " + new String(cipherText));
          encrPass = new String(cipherText);
      //return encrPass;
      }catch (Exception ex){
          System.out.println("Something went wrong");
          }
      return encrPass;
    }
}