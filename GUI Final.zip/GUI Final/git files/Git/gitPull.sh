#!/bin/bash
cd "$1"
git pull "$2" "$3"