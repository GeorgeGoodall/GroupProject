#!/bin/bash
cd "$1"
git log -"$2"
