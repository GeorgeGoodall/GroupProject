#!/bin/bash
cd "$1"
git clone "$2"