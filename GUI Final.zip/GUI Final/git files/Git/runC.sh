#/!bin/bash

echo $1;
echo $2;

count=`ls -1 "$1"*.c 2>/dev/null | wc -l`
if [ $count != 0 ]
then 
echo true
rsync -au "$1" ubuntu@10.72.97.156:~/ToRun/
ssh ubuntu@10.72.97.156 "cd ToRun && gcc -o project *.c && ./project"
rsync -au ubuntu@10.72.97.156:~/ToRun/ "$2"
ssh ubuntu@10.72.97.156 "rm ToRun/*"

rm "$2"project
cd "$1" || { echo "Failed to get in correct directory" ; exit 1 ; }
find . -type f -exec rm -f "$2"{} \;
rsync -au "$2" ubuntu@10.72.97.107:~/Documents/Data/
rm -r "$2"

else
echo false
fi 

