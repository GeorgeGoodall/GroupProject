#!/bin/bash
cd "$1"
git init 
