import java.io.IOException;
import com.jcraft.jsch.*;
import java.util.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import java.io.*;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class groupUploadFileController {
	
	@FXML
	private Text txt_error;
	@FXML
	private PasswordField passFieldDownload;
	
	@FXML
	private TextField usernameBox;
	
	@FXML
	private TextField filenameBox;
	
	@FXML
	private TextField serverBox;
	
	
	@FXML
	private TextField directoryBox;
	
	@FXML
	public void uploadFile(ActionEvent event) throws IOException {
		//testing if login details are correct go here
		int sFTPPORT = 22;
		String sFTPUSER = usernameBox.getText();
		String fileName = filenameBox.getText();
		String sFTPHOST = serverBox.getText();
		String sFTPPASS = "../keys/id_rsa";
		String sFTPWORKINGDIR = directoryBox.getText();
		Session session = null;
		Channel channel = null;
        ChannelSftp channelSftp = null;
        try {
            JSch jsch = new JSch();
            jsch.addIdentity(sFTPPASS);
            session = jsch.getSession(sFTPUSER, sFTPHOST, sFTPPORT);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            channelSftp = (ChannelSftp) channel;
            channelSftp.cd(sFTPWORKINGDIR);
            File f = new File(fileName);
            channelSftp.put(new FileInputStream(f), f.getName());

        } catch (Exception ex) {
             System.out.println("Exception found while tranfer the response.");
        }
        finally{

            channelSftp.exit();
            channel.disconnect();
            session.disconnect();
        }
		//String sFTPPASS = passFieldDownload.getText();
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/GroupUploadOK.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	public void showRegister(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Register.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	@FXML
    void initialize() {
        assert passFieldDownload != null : "fx:id=\"passFieldDownload\" was not injected: check your FXML file 'passport.fxml'.";
        assert usernameBox != null : "fx:id=\"usernameBox\" was not injected: check your FXML file 'passport.fxml'.";
        assert filenameBox != null : "fx:id=\"filenameBox\" was not injected: check your FXML file 'passport.fxml'.";

    }
	
	
}
