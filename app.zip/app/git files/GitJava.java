
import java.lang.ProcessBuilder;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.lang.Thread;

public class GitJava{
	
	

	/*
		***notes***
		need to add the ability to generate ssh keys
	*/

	public GitJava(){
		
	}
	
public String[] getUntracked(String[] status){
		
		boolean atUntracked = false;
		boolean atUntrackedFiles = false;
		ArrayList<String> files = new ArrayList<String>();
		
		for(int i = 0; i < status.length; i++){
			if(status[i].contains("Untracked files:")){
				atUntracked = true;
			}
			if(atUntracked && status[i].equals("")){
				atUntrackedFiles = true;
				continue;
			}
			if(atUntrackedFiles){
				if(status[i].equals("") || status[i].equals("no changes added to commit (use \"git add\" and/or \"git commit -a\")")  || status[i].contains("nothing added to commit")){
					return files.toArray(new String[files.size()]);
				}
				else{
					String f = status[i];
					int p = f.indexOf("\t");
					f = f.substring(p+1);
					files.add(f);
				}
			}
		}
		return files.toArray(new String[files.size()]);
	}

	public String[] getModified(String[] status){
		boolean atModified = false;
		boolean atModifiedFiles = false;
		ArrayList<String> files = new ArrayList<String>();
		
		for(int i = 0; i < status.length; i++){
			if(status[i].contains("Changes not staged for commit:")){
				atModified = true;
			}
			if(atModified && status[i].equals("")){
				atModifiedFiles = true;
				continue;
			}
			if(atModifiedFiles){
				if(status[i].equals("Untracked files:") || status[i].contains("changes added to commit") ){
					return files.toArray(new String[files.size()]);
				}
				else{
					String f = status[i];
					int p = f.indexOf(":");
					f = f.substring(p+4);
					files.add(f);
				}
			}
		}
		return files.toArray(new String[files.size()]);
	}

	public String[] getStaged(String[] status){
		boolean atRFC = false; // ready for commit
		boolean atRFCFiles = false;
		ArrayList<String> files = new ArrayList<String>();
		
		for(int i = 0; i < status.length; i++){
			if(status[i].contains("Changes to be committed:")){
				atRFC = true;
			}
			if(atRFC && status[i].equals("")){
				atRFCFiles = true;
				continue;
			}
			if(atRFCFiles){
				if(status[i].equals("Changes not staged for commit:") || status[i].equals("Untracked files:")){
					return files.toArray(new String[files.size()]);
				}
				else{
					String f = status[i];
					int p = f.indexOf(":");
					f = f.substring(p+4);
					files.add(f);
				}
			}
		}
		return files.toArray(new String[files.size()]);
	}
	
	public String[] getUpToDate(String folderPath,String[] nonUpToDateFiles){
		File folder = new File(folderPath);
		ArrayList<String> files = new ArrayList<String>();
	    for (final File fileEntry : folder.listFiles()) {
	        if (fileEntry.isDirectory()) {
	            
	        } else {
	        	if(Arrays.asList(nonUpToDateFiles).contains(fileEntry.getName())){
	        		
	        	}
	        	else{
	        		files.add(fileEntry.getName());
	        	}
	        }
	    }
	    
	    
	    return files.toArray(new String[0]);
	}
	

	public String[] status(String directory, String[] args){ return runProcess(directory, "gitStatus.sh", args); }

	public String[] add(String directory, String[] args){System.out.println(args[0]); return runProcess(directory, "gitadd.sh", args); }

	public String[] commit(String directory, String[] args){ return runProcess(directory, "gitcommit.sh", args); }

	public String[] remove(String directory, String[] args){ return runProcess(directory, "gitRemove.sh", args); }

	public String[] init(String directory, String[] args){ return runProcess(directory, "gitInit.sh", args); }

	public String[] pull(String directory, String repo, String branchname){ return runProcess(directory, "gitPull.sh", new String[]{repo,branchname}); }
	
	public String[] push(String directory, String repo, String branchname){ 
		return runProcess(directory, "gitPush.sh", new String[]{repo,branchname});
	}
	
	public String[] run(String directory, String location){
		return runProcess(directory, "runC.sh", new String[]{"/home/c1511942/yupp/"});
	}

	public String[] gitclone(String directory, String[] args){ return runProcess(directory, "gitClone.sh", args); }

	public String[] remote(String directory, String[] args){ return runProcess(directory, "gitRemote.sh", args); }	

	public String[] branch(String directory, String[] args){ return runProcess(directory, "gitBranch.sh", args); }

	public String[] checkout(String directory, String[] args){System.out.println("changing branch"); return runProcess(directory, "gitCheckout.sh", args); }

	public String[] log(String directory, String[] args){ return runProcess(directory, "gitlog.sh", args); }

	public String[] merge(String directory, String[] args){ return runProcess(directory, "gitMerge.sh", args); }

	// a .gitignore file can be created and eddited to allow files to be ignored by git
	public String[] getGitIgnore(String directory){
		ArrayList<String> output = new ArrayList<String>();
		try{
			FileReader fr = new FileReader(directory + "/.gitignore");
			BufferedReader br = new BufferedReader(fr);
			String line = null;
			while((line = br.readLine()) != null){
				output.add(line);
			}
			br.close();
		}
		catch(Exception e){
			System.out.println("error : " + e);
		}
		return output.toArray(new String[0]);
	}

	public void setGitIgnore(String directory, String[] lines){
		try{
    		PrintWriter writer = new PrintWriter(directory + "/.gitignore", "UTF-8");
    		for (int i = 0; i<lines.length; i++){
    			writer.println(lines[i]);
    		}
    		writer.close();
		} catch (IOException e) {
   			System.out.println("Error setting gitignore : " + e);
		}
	}

	private String[] runProcess(String directory,String operation, String[] args){

		ArrayList<String> resultlist = new ArrayList<String>();

		// make proceSystem.out.println();ssBuilder and set directory
		List<String> perams = new ArrayList<String>();
		perams.add(0,System.getProperty("user.dir") + "/Git/" + operation);
		perams.add(1,directory);
		
		for(int i = 0; i < args.length; i++){
			perams.add(args[i]);
		}
		ProcessBuilder pb = new ProcessBuilder("/bin/bash");
		pb.command(perams);
		pb.directory(new File(System.getProperty("user.dir")));
		
		try{
			Process process = pb.start();
			//create needed objects to read output
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String line;
			int c;

			try{
				while((line = br.readLine()) != null){
					resultlist.add(line);;
				}
			}
			catch(Exception e){
				System.out.println("Error reading bash script output: " + e);
			}
			//Wait to get exit value
        	try {
            	int exitValue = process.waitFor();
	        } 
	        catch (InterruptedException e) {

	        }
	        
		}
		catch(Exception e){System.out.println("Error starting processBuilder: " + e);}
		
		return resultlist.toArray(new String[0]);
	}
	
	public static void printResult(String[] res){
		if (res.length > 0)
		{
			System.out.println("\nResult:\n");
			for(int i = 0; i<res.length; i++){
				System.out.println("\t" + res[i]);
			}
		}
	}
}
