ssh ubuntu@10.72.97.107 "mkdir \"$1\" && sh gitInitbare.sh \"$1\""
