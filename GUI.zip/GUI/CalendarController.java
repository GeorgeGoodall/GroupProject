
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;


public class CalendarController {
	private static Connection con;
	private static Statement st;
	private static ResultSet rs;
	@FXML
    private TextField taskName;
	@FXML
    private TextField assignTask;
	@FXML
    private DatePicker subDate;
	@FXML
    private TextField subTime;
	@FXML
	
	public void showHomeScreen(ActionEvent event) throws IOException{
		
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("Calendar.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Home");
		stage.show();
	}
	
	public void showHomePage(ActionEvent event) throws IOException{
		
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Home");
		stage.show();
	}
	public static void connectDB(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://csmysql.cs.cf.ac.uk/c1522412","c1522412","UQPOMhh3g");
			st = con.createStatement();
		}catch(Exception ex){
			System.out.println("Error: "+ex);
		} 
	}
	public static void insertTask(String taskname, String assignname,LocalDate date, String time){
		String query = "insert into calendar(taskname,assignname,date,time) values ('"+taskname+"', '"+assignname+"', DATE '"+date+"', '"+time+"')";
		try {
			st.executeUpdate(query);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public static void checkTask(String taskname, String assignname, LocalDate date1, String Time){
		insertTask(taskname,assignname,date1,Time);
		System.out.println("added to database");
	}

	public void createTask(ActionEvent event) throws IOException{
		connectDB();
		checkTask(taskName.getText(),assignTask.getText(),subDate.getValue(),subTime.getText());
		taskName.clear();
		assignTask.clear();
		subTime.clear();
		
	}
}
