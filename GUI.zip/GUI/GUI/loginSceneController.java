import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.io.File;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import java.sql.Blob;
import com.encrDecr;

public class loginSceneController {
	// JDBC driver name and database URL
        static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        static final String DB_URL = "jdbc:mysql://csmysql.cs.cf.ac.uk/c1522412" ;

        //  Database credentials
        static final String USER = "c1522412";
        static final String PASS = "UQPOMhh3g";    
        @FXML
        private Label labelMessage;
        @FXML
        private TextField txtUsername; 
        @FXML
        private PasswordField txtPassword;
	@FXML
	private Text txt_error;
	
	public void showErrorMessage(ActionEvent event) throws IOException {
            if(txtUsername.getText().equals("") || txtPassword.getText().equals("")) {
            labelMessage.setText("Please enter your credentials or Sign Up");
        }
        else{
        Connection conn = null;
        Statement stmt = null;
        try{
           //STEP 2: Register JDBC driver
           //Class.forName("com.mysql.jdbc.Driver");

           //STEP 3: Open a connection
           System.out.println("Connecting to database...");
           conn = DriverManager.getConnection(DB_URL,USER,PASS);

           //STEP 4: Execute a query
           System.out.println("Creating statement...");
           stmt = conn.createStatement();
           String sql;
           sql = "SELECT ID, username, password  FROM Users where userName = '" + txtUsername.getText() + "'";
           ResultSet rs = stmt.executeQuery(sql);

           //STEP 5: Extract data from result set
            if(rs.next()){
               //Retrieve by column name
               int id  = rs.getInt("id");
               String username = rs.getString("userName");
               Blob password = rs.getBlob("password");


               //encrypt the pass from encrDecr.java file 
               encrDecr encrypt = new encrDecr();
                String encrPass = encrypt.Encryption(txtPassword.getText());
                //encrypt_txt.setText(new String(cipherText));

             System.out.println("cipher: " + new String (encrPass));
             
               //Display values 
               //convert blob into string
               String passwordFix = new String(password.getBytes(1l, (int) password.length()));
               
               if (passwordFix.equals( new String (encrPass)) && username.equals(txtUsername.getText())){
                   //System.out.println("Fixed Pass; " + fixPass.getClass().getSimpleName());
                   System.out.println("ID: " + id);
                   System.out.println(" Password: " + password);
                   
                   //create db for SQLite
                    File file = new File("C:\\sqliteDB");
                    if (!file.exists()){
                        if(file.mkdir()){
                            System.out.println("Directory is created!");
                            String url = "jdbc:sqlite:C:/sqliteDB/DB.db";
                            try (Connection connSQLite = DriverManager.getConnection(url)) {
                                    if (connSQLite != null) {
                                        DatabaseMetaData meta = connSQLite.getMetaData();
                                        System.out.println("The driver name is " + meta.getDriverName());
                                        System.out.println("A new database has been created.");

                                    }

                                } catch (SQLException e) {
                                    System.out.println(e.getMessage());
                                }

                        } else{
                            System.out.println("Failed to create directory");
                        }
                    }else{
                        System.out.println("Directory already exists");
                    }    
                        //create new DB
                        String url = "jdbc:sqlite:C:/sqliteDB/DB.db";
                        
                        File file2 = new File ("C:\\sqliteDB\\DB.db");
                            if(file2.exists()){
                                System.out.println("DB already exists so creating table IF it doesn't exist already");
                                
                                String sqlCreateTable = "CREATE TABLE IF NOT EXISTS Users (\n"
                                + "	id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                                + "	name varchar(30) UNIQUE,\n"//inique prevents from dublicates
                                + "	password BLOB"
                                + ");";
                                                                
                                 try (Connection connSQLite = DriverManager.getConnection(url);
                                    Statement stmtSQLite = connSQLite.createStatement()) {
                                // create a new table
                                stmtSQLite.execute(sqlCreateTable);
                                } catch (SQLException e) {
                                    System.out.println(e.getMessage());
                                }
                                System.out.println("Table created");
                               
                                //insert values     
                                String sqlInsert = "INSERT INTO Users(name, password) VALUES(?,?)";
                                try (Connection connSQLite = DriverManager.getConnection(url);

                                    PreparedStatement pstmt = connSQLite.prepareStatement(sqlInsert)) {
                                    //insert name and password                                
                                    pstmt.setString(1, txtUsername.getText());
                                    pstmt.setString(2, encrPass);
                                    pstmt.executeUpdate();
                                    System.out.println("Values inserted");
                                } catch (SQLException e) {
                                    //will say that unique constraint faile but it didn't
                                    System.out.println(e.getMessage());
                                }

                                
                            }else{
                                System.out.println("3");
                                //leave in case someone deleted the db but not the directory
                                DriverManager.registerDriver(new com.mysql.jdbc.Driver ());
                                try (Connection conn2 = DriverManager.getConnection(url)) {
                                    if (conn2 != null) {
                                        DatabaseMetaData meta = conn2.getMetaData();
                                        System.out.println("The driver name is " + meta.getDriverName());
                                        System.out.println("A new database has been created.");
                                    }

                                } catch (SQLException e) {
                                    System.out.println(e.getMessage());
                                  }                                                                
                                 }

          
		//testing if login details are correct go here
		txt_error.setVisible(true);
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Home.fxml"));
		Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.setTitle("Login");
                stage.show();
	}
                else{
            labelMessage.setText("Password incorrect");
        }

               
            }
            //STEP 6: Clean-up environment
            else{
            labelMessage.setText("Username incorrect");
            }
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){

            //create new DB
            String url = "jdbc:sqlite:C:/sqliteDB/DB.db";

            File file2 = new File ("C:\\sqliteDB\\DB.db");
                if(file2.exists()){
                    System.out.println("offline DB exists, woo!");
                    
                    //insert values     
                    //theoretically should prevent from dublicates
                    String sqlRetrieve = "SELECT id, name, password FROM Users where name = '" + txtUsername.getText() + "'";
                    try (Connection connSQLite = DriverManager.getConnection(url);
                        Statement stmtOffline = connSQLite.createStatement();
                        ResultSet rs    = stmtOffline.executeQuery(sqlRetrieve)) {
                        
                        //retrieve values                               
                        if(rs.next()){
                            //Retrieve by column name
                            int id  = rs.getInt("id");
                            String username = rs.getString("name");
                            
                            String password = rs.getString("password");
                            
                           //encrypt password
                           encrDecr encrypt = new encrDecr();
                           String encrPass = encrypt.Encryption(txtPassword.getText());

                            if (password.equals( encrPass) && username.equals(txtUsername.getText())){
                                //System.out.println("Fixed Pass; " + fixPass.getClass().getSimpleName());
                                //System.out.println("ID: " + id);
                                //System.out.println(" Password: " + password);
                                
                                ((Node) (event.getSource())).getScene().getWindow().hide();
                                Stage stage = new Stage();
                                Parent root = FXMLLoader.load(getClass().getResource("/Home.fxml"));
                                Scene scene = new Scene(root);
                                stage.setScene(scene);
                                stage.setTitle("Login");
                                stage.show();
                        //System.out.println("Values inserted");
                    } 
                        }else{
                            labelMessage.setText("offline database hasn't got your credentials");   
                            }
                }catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                }
        }

        }}
	public void showRegister(ActionEvent event) throws IOException {
		((Node) (event.getSource())).getScene().getWindow().hide();
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/Register.fxml"));
		Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
	}
	
	
}
